import React, { useState } from 'react';
import data from "../db/shoes"; // data import
import Products from "../components/Products";

const Form = () => {
  const [formData, setFormData] = useState({
    brand: '',
    color: '',
    type: '',
    price: ''
  });

  const [filteredShoes, setFilteredShoes] = useState([]);  // filteredShoes 상태 추가

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleColorSelection = (color) => {
    setFormData({
      ...formData,
      color: color
    });
  };


  const handleSubmit = (e) => {
    e.preventDefault();

    // shoes 배열에서 필터링
    const filteredShoesList = data.filter(shoes => {
      const brandMatch = formData.brand === '' || shoes.brand.toLowerCase() === formData.brand.toLowerCase();
      const colorMatch = formData.color === '' || shoes.color.toLowerCase() === formData.color.toLowerCase();
      const typeMatch = formData.type === '' || shoes.type.toLowerCase() === formData.type.toLowerCase();
      const priceMatch = formData.price === '' || shoes.price <= parseInt(formData.price);

      return brandMatch && colorMatch && typeMatch && priceMatch;
    });

    // 필터링된 신발 목록을 상태로 업데이트
    setFilteredShoes(filteredShoesList);
  };


  let [shoes, setShoes] = useState(data);

  return (
    <div className="container mt-5">
      <h2 className="text-center">신발 추천</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="brand">브랜드:</label>
          <select
            className="form-control"
            id="brand"
            name="brand"
            value={formData.brand}
            onChange={handleChange}
          >
            <option value="">선택 안함</option>
            <option value="Valentino">Valentino</option>
            <option value="Aldo">Aldo</option>
            <option value="Tory">Tory</option>
            <option value="Olympia">Olympia</option>
            <option value="Nike">Nike</option>
          </select>
        </div>

        <div className="form-group" style={{ marginTop: "20px" }}>
          <label>색상:</label><br />
          <div
            id="colorOptions"
            style={{
              display: "flex",
              flexWrap: "nowrap",
              gap: "10px",
              overflowX: "auto",
              width: "100%",
              cursor: 'pointer',
            }}
          >
            {[ // 색상 아이콘들
              { color: 'colorful', style: { background: `linear-gradient(45deg, #FF69B4 50%, red 50%), linear-gradient(-45deg, #1E90FF 50%, green 50%), linear-gradient(135deg, #1E90FF 50%, gold 50%), linear-gradient(-135deg, #FF69B4 50%, red 50%)`, backgroundSize: "50% 50%", backgroundPosition: "top left, top right, bottom left, bottom right", backgroundRepeat: "no-repeat" }},
              { color: 'brown', style: { backgroundColor: "#A52A2A" }},
              { color: 'green', style: { backgroundColor: "green" }},
              { color: 'black', style: { backgroundColor: "black" }},
              { color: 'blue roan', style: { background: `linear-gradient(45deg, #FFFFFF 25%, #000000 25%, #000000 50%, #FFFFFF 50%, #FFFFFF 75%, #000000 75%, #000000 100%)`, backgroundSize: "20px 20px" }},
              { color: 'red', style: { backgroundColor: "red" }},
              { color: 'beige', style: { backgroundColor: "#F5F5DC" }},
              { color: 'white', style: { backgroundColor: "white", border: "3px solid #ccc" }},
              { color: 'pink', style: { backgroundColor: "#FFC0CB" }},
              { color: 'orange', style: { backgroundColor: "orange" }},
              { color: 'purple', style: { backgroundColor: "purple" }}
            ].map((colorObj, index) => (
              <div
                key={index}
                className="color-icon"
                style={{ ...colorObj.style, width: "50px", height: "50px" }}
                onClick={() => handleColorSelection(colorObj.color)}
              ></div>
            ))}
          </div>
        </div>

        <div className="form-group" style={{ marginTop: "20px" }}>
          <label htmlFor="type">타입:</label>
          <select
            className="form-control"
            id="type"
            name="type"
            value={formData.type}
            onChange={handleChange}
          >
            <option value="">선택 안함</option>
            <option value="unique">유니크</option>
            <option value="comfortable">발편한</option>
            <option value="dress shoes">구두</option>
            <option value="boots">부츠</option>
            <option value="block heel">블록 구두</option>
            <option value="sandals">샌들</option>
          </select>
        </div>

        <div className="form-group" style={{ marginTop: "20px" }}>
          <label htmlFor="price">가격 (원):</label>
          <select
            className="form-control"
            id="price"
            name="price"
            value={formData.price}
            onChange={handleChange}
          >
            <option value="">선택 안함</option>
            <option value="50000">50,000원 이하</option>
            <option value="100000">100,000원 이하</option>
            <option value="150000">150,000원 이하</option>
            <option value="200000">200,000원 이하</option>
            <option value="300000">300,000원 이하</option>
          </select>
        </div>

        <button type="submit" className="btn btn-primary mt-3">추천받기</button>
      </form>

      {/* 필터링된 신발 목록 출력 */}
      <div className="container" style={{ marginTop: "30px" }}>
          <div className="row">
            {filteredShoes.length > 0 ? (
              filteredShoes.map((Shoes, i) => {
                return (
                  <Products shoes={Shoes} i={i} key={Shoes.id} />
                );
              })
            ) : (
              <p>조건에 맞는 신발이 없습니다. 신발을 골라보세요.</p> // 조건에 맞는 신발이 없을 경우 표시
            )}
          </div>
      </div>



    </div>
  );
};

export default Form;
