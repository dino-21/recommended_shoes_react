import React from "react";
import { useState } from "react";
import { useParams } from "react-router-dom";
import { Nav } from "react-bootstrap";
import { useEffect } from "react";
import { addItem } from "../store.js";
import { useDispatch } from "react-redux";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import styled from "styled-components";

let Box = styled.div`
  margin: 20px 0 30px 0 ;
  color: gray;
`;

let YellowBtn = styled.button`
  color: white;
  font-size: 30px;
  width: 100%;
  padding: 100px 100px;
  border: 1px solid #ccc;
  background-image: url("/recommended_shoes_react/img/banner4.jpg"); 
  background-size: cover;
  background-position: center;
`;

function Detail(props) {
  let { id } = useParams();
  // console.log(id);
  // console.log(Number(id) + 1);
  let [tap, setTap] = useState(0);
  let [fade2, setFade2] = useState("");
  useEffect(() => {
    setFade2("end");
    return () => {
      setFade2("");
    };
  }, []);

  let selproduct = props.shoes.find((x) => x.id == id);
  let dispatch = useDispatch();

  return (
    <div className={"container start " + fade2}>
      <Box>
        <YellowBtn>지금 구매하면 10% 할인</YellowBtn>
      </Box>
      {/* <h6>{selproduct.type} > {selproduct.brand} > {selproduct.title}</h6> */}
      <h6>{selproduct.type.toUpperCase()} > {selproduct.brand} > {selproduct.title}</h6>
      <div className="row" style={{ marginBottom: "50px" }}>
        <div className="col-md-6">
          <img src={"/recommended_shoes_react/" + selproduct.imgUrl} width="80%" imgUrl={selproduct.imgUrl} />
        </div>
     
        <div className="col-md-6" >
          <h4 className="pt-5">{selproduct.title}</h4>
          <p>{selproduct.content}</p>
          <p>{selproduct.price}</p>
          <Button
            variant="primary"
            onClick={() => {
              //  dispatch(addItem(  {id : 2,  imgurl : 'shoes1.jpg', name : 'Grey Yordan', count : 1}))

              dispatch(
                addItem({
                  id: selproduct.id,
                  imgurl: selproduct.imgUrl.replace("recommended_shoes_react/img/", ""),
                  name: selproduct.title,
                  count: 1,
                })
              );
            }}
            style={{ marginRight: "10px" }}
          >
            주문하기
          </Button>

          <Link to="/cart" >
            <Button variant="outline-success"> 주문상품 확인하기 </Button>
          </Link>
        </div>
      </div>

      <Nav variant="tabs" defaultActiveKey="link0">
        <Nav.Item>
          <Nav.Link
            onClick={() => {
              setTap(0);
            }}
            eventKey="link0"
          >
            버튼0
          </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link
            onClick={() => {
              setTap(1);
            }}
            eventKey="link1"
          >
            버튼1
          </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link
            onClick={() => {
              setTap(2);
            }}
            eventKey="link2"
          >
            버튼2
          </Nav.Link>
        </Nav.Item>
      </Nav>

      {/* TabContent에 selproduct 전달 */}
      <TabContent tap={tap} selproduct={selproduct} />
    </div>
  );
}

function TabContent({ tap, selproduct  }) {
  let [fade, setFade] = useState("");
  useEffect(() => {
    setTimeout(() => {
      setFade("end");
    }, 10);
    return () => {
      setFade("");
    };
  }, [tap]);

  return (
    <div className={"start " + fade} >
      {[<div>
  
        <img src={"/recommended_shoes_react/" + selproduct.imgUrl} width="80%" alt="Product Image" />
        <h4 className="pt-5">{selproduct.title}</h4>
          <p>{selproduct.content}</p>
          <p>{selproduct.price}</p>

          <p>상세정보 추가하기 (json에서 데이터만들기)</p>

      </div>, 
      
      
      <div>내용1</div>, <div>내용2</div>][tap]}
    </div>

  );
}
export default Detail;
