import React from "react";

const Title2 = () => {
  let csst1 = {
    marginTop: "70px",
  };
  return (
    <>
      <h3 style={csst1}>여름을 위한 컬렉션</h3>
      <p>가볍게, 시원하게 썸머 컬렉션으로 여름을 준비해 보세요.</p>
    </>
  );
};

export default Title2;
